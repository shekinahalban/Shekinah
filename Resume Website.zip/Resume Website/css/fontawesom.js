html { 
  background: url(../images/Background2.jpg) no-repeat center;
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
}
.profile_pic {
    height: 270px;
    border-radius: 50%;
    filter: opacity(85%)
}

head
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333333;
}

li {
  float: right;
}

li a {
  display: block;
  border-radius: 20%;
  color: dimgrey;
  font-size: 18;
  text-align: center;
  padding: 15px;
  text-decoration: none;
  font-family: "helvetica" inherit;
  margin-right: 7

}

li a:hover {
  background-color: pink;
}

body 

.video {
    float: right;
    margin-top: 55;
    
}

.content {
    background-color: rgba(0,0,0,0.2);
    color:floralwhite;
    padding: 60px;
    margin: auto;
    font-family: "Helvetica";
}

#name {
    position: fixed;
    left: 380;
    top: 50
}

#occupation {
    position: fixed;
    left: 380;
    top: 100
}

#about{
    position: fixed;
    text-align: justify;
    left: 380;
    top: 150;
    margin-right: 500
    
}

.middle{
    transform: translateY(-50%);
    width: 100%;
    text-align: center;
}
.btn{
    display: inline-block;
    width: 60px;
    height: 60px;
    background: #f1f1f1;
    margin: 0;
    border-radius: 30%;
    box-shadow: 0 5px 15px -5px #00000070;
    color: #3498db;
    overflow: hidden;
    position: relative;
}
.btn i{
    line-height: 60px;
    font-size: 26px;
    transition: 0.2s linear;
}
.btn:hover i{
    transform: scale(1.3);
    color: #f1f1f1;
}
.btn::before{
    content: "";
    position: absolute;
    width: 120%;
    height: 120%;
    background: #3498db;
    transform: rotate(45deg);
    left: -110%;
    top: 90%;
}
.btn:hover::{
    animation: aaa 0.7s 1;
    top: -10%;
    left: -10%;
}
@keyframes aaa {
    0%{
    left: -110%;
    top: 90%;
    }50%{
    left: 10%;
    top: -30%;
    }100%{
    left: -10%;
    top: 10%; 
}



